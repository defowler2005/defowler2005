import { world, system, ItemStack } from '@minecraft/server'
import { configurations } from '../library/build/configurations.js';
import { disableWatchdog } from '@minecraft/debug-utilities';
import '../library/Minecraft.js';
import '../example/commands/staff/gui.js';
import { gui } from '../example/commands/staff/gui.js';
import '../library/features/chat_ranks.js';
import '../library/features/sidebar_ui.js';

disableWatchdog(true);

world.afterEvents.buttonPush.subscribe((data) => {
    const x = Math.floor(data.block.x);
    const y = Math.floor(data.block.y);
    const z = Math.floor(data.block.z);
    const player = data.source;

    if (x === -108 && y === -59 && z === 18 && !player.hasTag('teleporting')) {
        player.addTag('teleporting');
        player.sendMessage('Teleporting...');
        system.runTimeout(() => { player.sendMessage('5') }, 20);
        system.runTimeout(() => { player.sendMessage('4') }, 40);
        system.runTimeout(() => { player.sendMessage('3') }, 60);
        system.runTimeout(() => { player.sendMessage('2') }, 80);
        system.runTimeout(() => { player.sendMessage('1') }, 100);
        system.runTimeout(() => {
            player.sendMessage('0');
            player.teleport({ x: -121, y: -60, z: -55 }, { dimension: player.dimension });
            player.removeTag('teleporting');
        }, 120);
    }
});

const minX = -99;
const minZ = -142;
const maxX = 21;
const maxZ = -234;

system.runInterval(() => {
    world.getPlayers().forEach((player) => {
        const x = Math.floor(player.location.x);
        const z = Math.floor(player.location.z);
        if (Math.abs(x - (minX + maxX) / 2) > Math.abs(minX - maxX) / 2 || Math.abs(z - (minZ + maxZ) / 2) > Math.abs(minZ - maxZ) / 2) {
            //player.sendMessage('You are outside the border!');
            player.removeEffect('speed');
        } else {
            //player.sendMessage('You are in the border!');
            player.addEffect('speed', 40, { showParticles: false, amplifier: 7 });
        }
    })
}, 20);

world.afterEvents.playerSpawn.subscribe((data) => {
    system.run(() => {
        const player = data.player;
        //if (data.initialSpawn === false) return;

        const inv = player.getComponent('minecraft:inventory').container;
        const mg_server_gui = new ItemStack('mg:server_gui', 1)
        mg_server_gui.keepOnDeath = true;
        mg_server_gui.lockMode = 'slot';
        inv.getSlot(0).setItem(mg_server_gui);
        player.addTag('rank:§b§lMember')
    });
});

world.afterEvents.itemUse.subscribe((data) => {
    const item = data.itemStack.typeId;
    const player = data.source;
    if (item === 'mg:server_gui') {
        if (!player.hasTag('welcome')) {
            gui.welcome.main(player);
            player.addTag('welcome')
            return;
        };
        if (player.hasTag(configurations.staffTag)) gui.staff.main(player);
        else return gui.player.main(player);
    }
});