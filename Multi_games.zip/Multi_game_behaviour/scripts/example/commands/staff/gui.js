import { Player, system } from '@minecraft/server';
import { commandBuild } from '../../../library/build/classes/commandBuilder.js';
import { configurations } from '../../../library/build/configurations.js';
import { buttonFormData } from '../../../library/build/classes/buttonFormData.js';
import { teleportTimer } from '../../../library/utils/teleport_timer.js';

/**
 * The gui object containg all UI's.
 */
export const gui = {
    staff: {
        main: (player) => { }
    },
    player: {
        main: (player) => {
            const main = new buttonFormData(player);
            main.create(
                {
                    title: 'Main',
                    body: [
                        ['Select an option...']
                    ],
                    button: [
                        ['Teleport']
                    ]
                }, (result) => {
                    gui.player.teleport(player)
                }
            )
        },
        teleport: (player) => {
            const main = new buttonFormData(player);
            main.create(
                {
                    title: 'Teleport',
                    body: [
                        ['Select an option...']
                    ],
                    button: [
                        ['Spawn'],
                        ['Shop']
                    ]
                }, (result) => {
                    if (result.selection === 0) {
                        player.sendMessage('Teleporting in 5 seconds.');
                        system.runTimeout(() => { player.sendMessage('5') }, 20);
                        system.runTimeout(() => { player.sendMessage('4') }, 40);
                        system.runTimeout(() => { player.sendMessage('3') }, 60);
                        system.runTimeout(() => { player.sendMessage('2') }, 80);
                        system.runTimeout(() => { player.sendMessage('1') }, 100);
                        system.runTimeout(() => {
                            player.sendMessage('0');
                            player.teleport({ x: -120.00, y: -60, z: -50.00 }, { dimension: player.dimenion })
                        }, 120)
                    }; //Spawn.
                }
            )
        }
    },
    welcome: {
        main: (player) => {
            const main = new buttonFormData(player);
            main.create(
                {
                    title: 'Welcome',
                    body: [
                        ['Welcome to the world of many games and adventures!\n'],
                        ['We are pleased that you could make it'],
                        [`\nThere are commands built in: ${configurations.commandPrefix}[command name]`]
                    ],
                    button: [
                        ['Alrighty, No worries!']
                    ]
                }, (result) => { }
            )
        }
    }
};

commandBuild.create(
    {
        name: 'gui',
        description: 'The ease of access utility gui',
        isStaff: false,
        aliases: ['ui'],
        examples: ['gui', 'ui'],
        usage: ['gui', 'ui']
    }, (data, args) => {
        /**
         * @type {Player}
         */
        const player = data.sender;
        player.sendMessage('Move to show the UI.');
    }, (data, args) => {
        /**
         * @type {Player}
         */
        const player = data.sender;
        if (!player.hasTag('welcome')) {
            gui.welcome.main(player);
            player.addTag('welcome')
            return;
        };
        if (player.hasTag(configurations.staffTag)) gui.staff.main(player);
        else return gui.player.main(player);
    }
);