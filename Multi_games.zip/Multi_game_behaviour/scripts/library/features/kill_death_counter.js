import { world } from '@minecraft/server';

world.afterEvents.entityDie.subscribe((data) => {
    const dead = data.deadEntity;
    const killer = data?.damageSource?.damagingEntity;
    if (!(killer instanceof Player) || !(dead instanceof Player)) return;
    const killObj = world.scoreboard.getObjective('kills');
    const deadObj = world.scoreboard.getObjective('deaths');
    const killScore = killObj.getScore(killer.scoreboardIdentity);
    const deadScore = deadObj.getScore(dead.scoreboardIdentity);
    killObj.setScore(killer.scoreboardIdentity, killScore + 1);
    deadObj.setScore(dead.scoreboardIdentity, deadScore + 1);
    dead.runCommandAsync('summon lightning_bolt ~~3~');
    dead.runCommandAsync('playsound random.levelup');
});