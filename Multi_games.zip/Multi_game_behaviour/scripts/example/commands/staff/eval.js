import { Player } from '@minecraft/server';
import { commandBuild } from '../../../library/build/classes/commandBuilder.js';
import { configurations } from '../../../library/build/configurations.js';

commandBuild.create(
    {
        name: 'eval',
        description: 'Execute javascript code',
        isStaff: false,
        aliases: ['js'],
        examples: ['eval', 'js'],
        usage: ['eval', 'js']
    }, (data, args) => {
        /**
         * @type {Player}
         */
        const player = data.sender;
        

    }, (data, args) => {
        /**
         * @type {Player}
         */
    }
);