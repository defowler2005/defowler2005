import { Player, system } from '@minecraft/server';

/**
 * teleportTimer.
 * @param {Player} player - The player object.
 * @param {{x: number, y: number, z: number}} coordinateSource - The coordinates that initiate the function.
 * @param {{x: number, y: number, z: number}} coordinateDestination - The coordinates to go to.
 */
export function teleportTimer(player, coordinateSource, coordinateDestination) {
    const { x, y, z } = player.location;

    if (Math.floor(x) === Math.floor(coordinateSource.x) && Math.floor(y) === Math.floor(coordinateSource.y) && Math.floor(z) === Math.floor(coordinateSource.z) && !player.hasTag('teleporting')) {
        player.addTag('teleporting');
        player.sendMessage('Teleporting...');
        system.runTimeout(() => player.sendMessage('5'), 20);
        system.runTimeout(() => player.sendMessage('4'), 40);
        system.runTimeout(() => player.sendMessage('3'), 60);
        system.runTimeout(() => player.sendMessage('2'), 80);
        system.runTimeout(() => player.sendMessage('1'), 100);

        system.runTimeout(() => {
            player.sendMessage('0');
            player.teleport({ x: Math.floor(coordinateDestination.x), y: Math.floor(coordinateDestination.y), z: Math.floor(coordinateDestination.z) }, { dimension: player.dimension }); // Destination coordinates
            player.removeTag('teleporting');
        }, 120);
    }
};