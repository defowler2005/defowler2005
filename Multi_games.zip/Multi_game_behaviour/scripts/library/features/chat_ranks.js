import { world } from "@minecraft/server";

world.beforeEvents.chatSend.subscribe((data) => {
    const message = data.message;
    const sender = data.sender;
    const allTags = sender.getTags().filter((tag) => tag.startsWith('rank:'))
    const rank = allTags.map((rank) => rank.slice('rank:'.length))
    data.cancel = true;
    if (allTags) world.sendMessage(`§8[§r${rank.join('§8,§r ')}§8]§r§f ${sender.name} ${message}`)
    else world.sendMessage(`<${sender.name}> ${message}`)
});