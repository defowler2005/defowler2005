import { system, world } from "@minecraft/server";
import { teleportTimer } from "../utils/teleport_timer.js";

system.runInterval(() => {
    world.getAllPlayers().forEach((player) => {
        teleportTimer(player, { x: -108, y: -60, z: -55 }, { x: -80, y: -60, z: -156 }); //Play game selection.

        player.onScreenDisplay.setTitle(
            {
                "rawtext": [
                    {
                        "text": "Some title."
                    }
                ]
            },
            {
                subtitle: '§c§l Multi-game.',
                stayDuration: 20,
                fadeInDuration: 0,
                fadeOutDuration: 0
            }
        );
    });
}, 10);